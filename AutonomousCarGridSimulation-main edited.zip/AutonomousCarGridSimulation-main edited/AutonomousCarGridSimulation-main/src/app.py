from __future__ import annotations

import threading
import tkinter as tk
from tkinter import ttk, messagebox
from typing import List, Optional

from src.grid import Grid, Cell
from src.evaluator import evaluate_algorithms
from src.presets import get_preset, list_presets
from src.algorithms import SearchResult
from src.algorithms.base import path_cost


CANVAS_SIZE = 620
DEFAULT_SPEED_MS = 120
ALGORITHM_OPTIONS = [
    "Auto (best)",
    "BFS",
    "DFS",
    "Uniform Cost",
    "Greedy Best-First",
    "A*",
    "IDA*",
    "Bidirectional",
]


class SimulatorGUI:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        root.title("Autonomous Car Grid Simulation")
        root.geometry("1000x720")

        self.grid_canvas = tk.Canvas(root, width=CANVAS_SIZE, height=CANVAS_SIZE, bg="white")
        self.grid_canvas.pack(side=tk.RIGHT, padx=10, pady=10)
        # bind canvas clicks for cell selection and weight setting
        self.grid_canvas.bind("<Button-1>", self.on_canvas_click)

        # Scrollable control panel
        self.controls_container = tk.Frame(root)
        self.controls_container.pack(side=tk.LEFT, fill=tk.Y, padx=10, pady=10)

        self.control_canvas = tk.Canvas(self.controls_container, borderwidth=0, highlightthickness=0)
        vsb = tk.Scrollbar(self.controls_container, orient=tk.VERTICAL, command=self.control_canvas.yview)
        self.control_canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        self.control_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.control_frame = tk.Frame(self.control_canvas)
        self.control_canvas.create_window((0, 0), window=self.control_frame, anchor="nw")

        def _on_control_configure(event):
            self.control_canvas.configure(scrollregion=self.control_canvas.bbox("all"))

        self.control_frame.bind("<Configure>", _on_control_configure)
        # support mouse wheel scrolling on Windows / macOS
        self.control_canvas.bind_all("<MouseWheel>", lambda e: self.control_canvas.yview_scroll(int(-1 * (e.delta / 120)), "units"))

        self.status_var = tk.StringVar(value="Ready")
        tk.Label(self.control_frame, textvariable=self.status_var, font=("Arial", 12, "bold")).pack(pady=(0, 6))

        # Preset selection
        tk.Label(self.control_frame, text="Preset grid").pack(anchor="w")
        self.preset_var = tk.StringVar(value=list_presets()[0])
        self.preset_combo = ttk.Combobox(
            self.control_frame, textvariable=self.preset_var, values=list_presets(), state="readonly", width=20
        )
        self.preset_combo.pack(anchor="w", pady=4)

        tk.Label(self.control_frame, text="Algorithm").pack(anchor="w", pady=(8, 0))
        self.algorithm_var = tk.StringVar(value=ALGORITHM_OPTIONS[0])
        self.algorithm_combo = ttk.Combobox(
            self.control_frame,
            textvariable=self.algorithm_var,
            values=ALGORITHM_OPTIONS,
            state="readonly",
            width=20,
        )
        self.algorithm_combo.pack(anchor="w", pady=4)

        # Custom controls
        tk.Label(self.control_frame, text="Custom grid (rows, cols)").pack(anchor="w", pady=(10, 0))
        custom_frame = tk.Frame(self.control_frame)
        custom_frame.pack(anchor="w")
        self.rows_var = tk.StringVar(value="12")
        self.cols_var = tk.StringVar(value="12")
        tk.Entry(custom_frame, textvariable=self.rows_var, width=5).pack(side=tk.LEFT, padx=2)
        tk.Entry(custom_frame, textvariable=self.cols_var, width=5).pack(side=tk.LEFT, padx=2)

        tk.Label(self.control_frame, text="Obstacle ratio (0-0.5)").pack(anchor="w", pady=(8, 0))
        self.obstacle_var = tk.StringVar(value="0.18")
        tk.Entry(self.control_frame, textvariable=self.obstacle_var, width=8).pack(anchor="w")

        tk.Label(self.control_frame, text="Weighted ratio (0-0.5)").pack(anchor="w", pady=(8, 0))
        self.weight_var = tk.StringVar(value="0.18")
        tk.Entry(self.control_frame, textvariable=self.weight_var, width=8).pack(anchor="w")

        # Buttons
        btn_frame = tk.Frame(self.control_frame)
        btn_frame.pack(anchor="w", pady=12)
        tk.Button(btn_frame, text="Start", command=self.start_simulation, width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(btn_frame, text="Pause", command=self.pause_animation, width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(btn_frame, text="Resume", command=self.resume_animation, width=8).pack(side=tk.LEFT, padx=2)
        tk.Button(btn_frame, text="Reset", command=self.reset, width=8).pack(side=tk.LEFT, padx=2)

        tk.Label(self.control_frame, text="Animation speed (ms)").pack(anchor="w", pady=(6, 0))
        self.speed_var = tk.IntVar(value=DEFAULT_SPEED_MS)
        tk.Scale(
            self.control_frame,
            from_=30,
            to=500,
            orient=tk.HORIZONTAL,
            variable=self.speed_var,
            length=180,
        ).pack(anchor="w")

        # Weight display / editor
        self.show_weights_var = tk.BooleanVar(value=False)
        tk.Checkbutton(self.control_frame, text="Show weights", variable=self.show_weights_var, command=lambda: self.draw_grid(self.current_grid) if self.current_grid else None).pack(anchor="w", pady=(8, 0))

        tk.Label(self.control_frame, text="Edit cell weight").pack(anchor="w", pady=(8, 0))
        edit_frame = tk.Frame(self.control_frame)
        edit_frame.pack(anchor="w")
        self.edit_weight_var = tk.StringVar(value="2.0")
        tk.Entry(edit_frame, textvariable=self.edit_weight_var, width=6).pack(side=tk.LEFT, padx=(0, 6))
        tk.Button(edit_frame, text="Click cell to set", command=self.enable_weight_edit, width=14).pack(side=tk.LEFT)

        # Visualization info: path and node exploration
        tk.Label(self.control_frame, text="Visualization Info", font=("Arial", 11, "bold")).pack(anchor="w", pady=(10, 0))
        self.viz_info_var = tk.StringVar(value="-")
        tk.Label(self.control_frame, textvariable=self.viz_info_var, justify="left", wraplength=200).pack(anchor="w")

        tk.Label(self.control_frame, text="Optimal algorithm", font=("Arial", 11, "bold")).pack(anchor="w", pady=(10, 0))
        self.best_var = tk.StringVar(value="-")
        tk.Label(self.control_frame, textvariable=self.best_var, justify="left").pack(anchor="w")

        tk.Label(self.control_frame, text="All results", font=("Arial", 11, "bold")).pack(anchor="w", pady=(10, 0))
        self.results_box = tk.Text(self.control_frame, height=18, width=38, state="disabled", wrap="word")
        self.results_box.pack(anchor="w")

        self.current_grid: Optional[Grid] = None
        self.selected_cell: Optional[tuple] = None
        self.best_result: Optional[SearchResult] = None
        self.visualized_result: Optional[SearchResult] = None
        self.dash_cost_var = tk.StringVar(value="-")
        self.dash_nodes_var = tk.StringVar(value="-")
        self.dash_time_var = tk.StringVar(value="-")
        self.selected_cell_var = tk.StringVar(value="None")
        self.selected_weight_var = tk.StringVar(value="")
        self.visualized_var = tk.StringVar(value="-")
        self.results: List[SearchResult] = []
        self.running = False
        self.paused = False
        self.animation_job: Optional[str] = None
        self.animation_index = 0
        # Path animation state
        self.path_index = 0
        self.path_prev: Optional[Cell] = None
        self.cumulative_cost = 0.0
        self.path_taken = []  # Track all steps taken so far
        self.editing_weight = False

    # Grid helpers
    def build_grid(self) -> Grid:
        try:
            rows = int(self.rows_var.get())
            cols = int(self.cols_var.get())
            obstacle_ratio = float(self.obstacle_var.get())
            weight_ratio = float(self.weight_var.get())
        except ValueError:
            messagebox.showerror("Invalid input", "Please enter valid numeric values.")
            raise

        # Clamp ratios to safe values
        obstacle_ratio = max(0.0, min(0.6, obstacle_ratio))
        weight_ratio = max(0.0, min(0.6, weight_ratio))
        return Grid.random_grid(
            rows=rows,
            cols=cols,
            obstacle_ratio=obstacle_ratio,
            weighted_ratio=weight_ratio,
            seed=42,  # deterministic for reproducibility
        )

    def draw_grid(self, grid: Grid) -> None:
        self.grid_canvas.delete("all")
        matrix = grid.as_matrix()
        cell_size = CANVAS_SIZE / max(grid.rows, grid.cols)
        for r in range(grid.rows):
            for c in range(grid.cols):
                x1, y1 = c * cell_size, r * cell_size
                x2, y2 = x1 + cell_size, y1 + cell_size
                cell: Cell = matrix[r][c]
                color = "white"
                if cell.obstacle:
                    color = "#1f2937"
                elif (r, c) == grid.start:
                    color = "#16a34a"
                elif (r, c) == grid.goal:
                    color = "#dc2626"
                elif cell.weight > 1:
                    color = "#fb923c"
                self.grid_canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="#e5e7eb")
                # Optionally show weight text
                if self.show_weights_var.get():
                    w_text = f"{cell.weight:.1f}" if cell.weight != 1.0 else "1"
                    self.grid_canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=w_text, fill="#000000", font=("Arial", max(8, int(cell_size // 5))))

    # Simulation lifecycle
    def start_simulation(self) -> None:
        if self.running:
            return
        self.running = True
        self.paused = False
        self.status_var.set("Running algorithms...")
        preset_name = self.preset_var.get()
        use_preset = messagebox.askyesno("Use preset?", f"Run preset '{preset_name}'? Choose No for custom grid.")
        try:
            grid = get_preset(preset_name) if use_preset else self.build_grid()
        except Exception:
            self.running = False
            return

        self.current_grid = grid
        self.draw_grid(grid)
        thread = threading.Thread(target=self._execute_algorithms, daemon=True)
        thread.start()

    def _execute_algorithms(self) -> None:
        grid = self.current_grid.clone() if self.current_grid else None
        if grid is None:
            return
        results, best = evaluate_algorithms(grid)
        self.results = results
        self.best_result = best
        self.root.after(0, self._after_algorithms)

    def _after_algorithms(self) -> None:
        if self.best_result is None or self.current_grid is None:
            self.status_var.set("No solution found.")
            self.running = False
            return
        visualized = self._resolve_visualized_result()
        selected_name = self.algorithm_var.get()
        if visualized is None or not visualized.success:
            if selected_name != "Auto (best)":
                messagebox.showwarning(
                    "Selection unavailable",
                    (
                        f"Algorithm '{selected_name}' did not produce a valid path. "
                        "Falling back to the optimal result."
                    ),
                )
            visualized = self.best_result
        if visualized is None:
            self.status_var.set("No solution found.")
            self.running = False
            return

        self.visualized_result = visualized
        self.status_var.set(
            f"Visualizing: {visualized.name} (Optimal: {self.best_result.name if self.best_result else 'N/A'})"
        )
        self.render_results()
        self.animation_index = 0
        self.animate_exploration()

    # Animation
    def animate_exploration(self) -> None:
        if not self.visualized_result or not self.current_grid:
            return
        if self.paused:
            return
        visited = self.visualized_result.visited_order
        if self.animation_index < len(visited):
            pos = visited[self.animation_index]
            self._highlight_cell(pos, "#3b82f6")
            self.animation_index += 1
            delay = max(10, self.speed_var.get())
            self.animation_job = self.root.after(delay, self.animate_exploration)
        else:
            # Start step-by-step path animation (shows cost accumulation)
            self.path_index = 0
            self.cumulative_cost = 0.0
            self.path_prev = None
            self.path_taken = []  # Reset path taken list
            self.animate_path()

    def _highlight_cell(self, pos, color: str) -> None:
        grid = self.current_grid
        if grid is None:
            return
        cell_size = CANVAS_SIZE / max(grid.rows, grid.cols)
        r, c = pos
        x1, y1 = c * cell_size, r * cell_size
        x2, y2 = x1 + cell_size, y1 + cell_size
        self.grid_canvas.create_rectangle(x1, y1, x2, y2, fill=color, outline="#e5e7eb")
        # If showing weights, redraw weight text on top
        if self.show_weights_var.get():
            cell = grid.cells.get(pos, Cell())
            w_text = f"{cell.weight:.1f}" if cell.weight != 1.0 else "1"
            self.grid_canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=w_text, fill="#000000", font=("Arial", max(8, int(cell_size // 5))))

    # Controls
    def pause_animation(self) -> None:
        self.paused = True
        if self.animation_job:
            self.root.after_cancel(self.animation_job)
            self.animation_job = None
        self.status_var.set("Paused")

    def resume_animation(self) -> None:
        if not self.running:
            return
        if not self.paused:
            return
        self.paused = False
        self.status_var.set("Resumed")
        self.animate_exploration()

    def reset(self) -> None:
        if self.animation_job:
            self.root.after_cancel(self.animation_job)
        self.running = False
        self.paused = False
        self.animation_job = None
        self.animation_index = 0
        self.best_result = None
        self.visualized_result = None
        self.results = []
        self.grid_canvas.delete("all")
        self.status_var.set("Ready")
        self.best_var.set("-")
        self.visualized_var.set("-")
        self.cumulative_cost = 0.0
        self.path_index = 0
        self.path_taken = []
        self.editing_weight = False
        self._write_results_text("")

    # Rendering info
    def render_results(self) -> None:
        if self.visualized_result:
            viz = self.visualized_result
            
            # Show complete path with all nodes
            path_detail = ""
            if viz.path:
                path_coords = " → ".join([f"({r},{c})" for r, c in viz.path])
                path_detail = f"Complete Path:\n{path_coords}\n"
            
            # Show all explored nodes
            explored_detail = ""
            if viz.visited_order:
                explored_coords = " → ".join([f"({r},{c})" for r, c in viz.visited_order])
                explored_detail = f"\nExplored Nodes ({len(viz.visited_order)}):\n{explored_coords}\n"
            
            info = (
                f"Algorithm: {viz.name}\n"
                f"Cost: {viz.cost:.3f} | Nodes explored: {viz.explored_nodes} | Time: {viz.duration:.4f}s\n"
                f"Path length: {len(viz.path) if viz.path else 0}\n"
                f"{path_detail}"
                f"{explored_detail}"
            )
            self.viz_info_var.set(info)
        else:
            self.viz_info_var.set("-")

        if self.best_result:
            best = self.best_result
            best_summary = (
                f"{best.name}\n"
                f"Cost: {best.cost}\n"
                f"Nodes: {best.explored_nodes}\n"
                f"Time: {best.duration:.4f}s\n"
            )
            self.best_var.set(best_summary)
        else:
            self.best_var.set("-")

        lines: List[str] = []
        for res in sorted(self.results, key=lambda r: r.cost):
            status = "OK" if res.success else "Fail"
            lines.append(
                f"{res.name}: cost={res.cost:.3f}, nodes={res.explored_nodes}, "
                f"time={res.duration:.4f}s, {status}"
            )
        self._write_results_text("\n".join(lines))

        # Aggregate dashboard: show avg / best / worst for cost, nodes and time across all algorithms
        if self.results:
            costs = [r.cost for r in self.results if isinstance(r.cost, (int, float))]
            nodes = [r.explored_nodes for r in self.results if isinstance(r.explored_nodes, int)]
            times = [r.duration for r in self.results if isinstance(r.duration, (int, float))]
            if costs:
                avg_cost = sum(costs) / len(costs)
                best_cost = min(costs)
                worst_cost = max(costs)
                self.dash_cost_var.set(f"avg {avg_cost:.3f} / best {best_cost:.3f} / worst {worst_cost:.3f}")
            else:
                self.dash_cost_var.set("-")

            if nodes:
                avg_nodes = sum(nodes) / len(nodes)
                best_nodes = min(nodes)
                worst_nodes = max(nodes)
                self.dash_nodes_var.set(f"avg {avg_nodes:.1f} / best {best_nodes} / worst {worst_nodes}")
            else:
                self.dash_nodes_var.set("-")

            if times:
                avg_time = sum(times) / len(times)
                best_time = min(times)
                worst_time = max(times)
                self.dash_time_var.set(f"avg {avg_time:.4f}s / best {best_time:.4f}s / worst {worst_time:.4f}s")
            else:
                self.dash_time_var.set("-")
        else:
            self.dash_cost_var.set("-")
            self.dash_nodes_var.set("-")
            self.dash_time_var.set("-")

    def _write_results_text(self, text: str) -> None:
        self.results_box.configure(state="normal")
        self.results_box.delete("1.0", tk.END)
        self.results_box.insert(tk.END, text)
        self.results_box.configure(state="disabled")

    # Weight editing
    def enable_weight_edit(self) -> None:
        if self.current_grid is None:
            messagebox.showinfo("No grid", "Build or load a grid first.")
            return
        try:
            float(self.edit_weight_var.get())
        except ValueError:
            messagebox.showerror("Invalid weight", "Please enter a numeric weight value.")
            return
        self.editing_weight = True
        self.status_var.set("Click a cell to set weight")

    def _cancel_weight_edit(self) -> None:
        self.editing_weight = False
        self.status_var.set("Ready")
    def set_selected_cell_weight(self) -> None:
        if self.current_grid is None:
            messagebox.showinfo("No grid", "Build or load a grid first.")
            return
        if not self.selected_cell:
            messagebox.showinfo("No cell selected", "Click a cell on the grid to select it first.")
            return
        try:
            w = float(self.selected_weight_var.get())
        except ValueError:
            messagebox.showerror("Invalid weight", "Please enter a numeric weight value.")
            return
        r, c = self.selected_cell
        if self.current_grid.cells.get((r, c), Cell()).obstacle:
            messagebox.showwarning("Obstacle", "Cannot set weight on an obstacle cell.")
            return
        self.current_grid.cells[(r, c)] = Cell(weight=w, obstacle=False)
        self.draw_grid(self.current_grid)
        # Ensure grid is saved
        messagebox.showinfo("Success", f"Weight set at ({r},{c})")

    def on_canvas_click(self, event) -> None:
        # Allow clicking to either set weight (when in edit mode) or select a cell
        if self.current_grid is None:
            return
        grid = self.current_grid
        cell_size = CANVAS_SIZE / max(grid.rows, grid.cols)
        c = int(event.x // cell_size)
        r = int(event.y // cell_size)
        if not grid.in_bounds((r, c)):
            return

        if self.editing_weight:
            try:
                w = float(self.edit_weight_var.get())
            except ValueError:
                messagebox.showerror("Invalid weight", "Please enter a numeric weight value.")
                return
            if grid.cells.get((r, c), Cell()).obstacle:
                messagebox.showwarning("Obstacle", "Cannot set weight on an obstacle cell.")
                return
            grid.cells[(r, c)] = Cell(weight=w, obstacle=False)
            # redraw and save grid state
            self.draw_grid(grid)
            self.current_grid = grid  # Ensure grid is saved
            self._cancel_weight_edit()
        else:
            # Select the clicked cell for manual weight editing via the Selected cell controls
            self.selected_cell = (r, c)
            self.selected_cell_var.set(f"{r},{c}")
            cell = grid.cells.get((r, c), Cell())
            self.selected_weight_var.set(str(cell.weight))

    # Path animation that shows cumulative cost as it steps along the path
    def animate_path(self) -> None:
        if not self.visualized_result or not self.current_grid:
            return
        path = self.visualized_result.path
        if self.path_index < len(path):
            pos = path[self.path_index]
            self.path_taken.append(pos)
            self._highlight_cell(pos, "#fde047")
            if self.path_prev is not None:
                step_cost = self.current_grid.cost(self.path_prev, pos)
                self.cumulative_cost += step_cost
            self.path_prev = pos
            
            # Build detailed path display
            path_coords = " → ".join([f"({r},{c})" for r, c in self.path_taken])
            path_progress = f"Step {self.path_index + 1}/{len(path)}: {pos}\nCost so far: {self.cumulative_cost:.3f}\n\nPath taken:\n{path_coords}"
            
            info = (
                f"Algorithm: {self.visualized_result.name}\n"
                f"Path Progress:\n"
                f"{path_progress}"
            )
            self.viz_info_var.set(info)
            self.status_var.set(f"Path: {self.path_index + 1}/{len(path)} | Current cost: {self.cumulative_cost:.3f}")
            self.path_index += 1
            delay = max(50, self.speed_var.get())
            self.animation_job = self.root.after(delay, self.animate_path)
        else:
            self.running = False
            # final cost compute to ensure accuracy
            total_cost = path_cost(self.current_grid, path) if path else 0.0
            path_coords = " → ".join([f"({r},{c})" for r, c in self.path_taken])
            final_info = (
                f"Algorithm: {self.visualized_result.name}\n"
                f"Path Complete!\n"
                f"Total steps: {len(path)}\n"
                f"Total cost: {total_cost:.3f}\n\n"
                f"Final path:\n{path_coords}"
            )
            self.viz_info_var.set(final_info)
            self.status_var.set(
                f"Finished. Total cost: {total_cost:.3f}"
            )

    def _resolve_visualized_result(self) -> Optional[SearchResult]:
        selected = self.algorithm_var.get()
        if selected == "Auto (best)":
            return self.best_result
        return next((r for r in self.results if r.name == selected), None)


def run() -> None:
    root = tk.Tk()
    SimulatorGUI(root)
    root.mainloop()


if __name__ == "__main__":
    run()
